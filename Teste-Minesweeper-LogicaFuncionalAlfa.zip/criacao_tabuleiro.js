let tam_linhas, tam_colunas
let posicoes_bombas = []
let num_bombas = 15 //NUMERO ARBITRARIO PARA TESTE
// let nome_jogador = "Joaquim" //NOME ARBITRARIO PARA TESTE
// let modalidade = "Classico" // ARBITRARIA PARA TESTE



function define_tamanho() {
    let linha = document.forms["tabuleiro"]["linha"].value
    let coluna = document.forms["tabuleiro"]["coluna"].value
    linha = Number(linha)
    coluna = Number(coluna)

     //falta criar o campo para o usuario escolher o numero de bombas!!

    cria_tabuleiro(linha,coluna)


    return false
}


function cria_tabuleiro(linhas,colunas) {
    tam_linhas = linhas
    tam_colunas = colunas
    limpa_tabuleiro()

    let cor_inicial = 0

    let linha = document.getElementsByClassName("linha")
    let jogo = document.getElementById("jogo")


    for(let i = 0; i < linhas; i++){
        let cria_linha = document.createElement("div")
        cria_linha.classList.add("linha") 
        jogo.appendChild(cria_linha)

        for(let n = cor_inicial; n < colunas; n++){
            let cria_quadrado = document.createElement("button")
            cria_quadrado.classList.add("quadrado") 
            
            n%2 ? cria_quadrado.classList.add("azul") : cria_quadrado.classList.add("roxo")

            let coluna = n - cor_inicial

            cria_quadrado.setAttribute("onclick", "pressiona_quadrado(" + i + "," + coluna + ")")
    

            linha[i].appendChild(cria_quadrado)            
        }
        colunas = (cor_inicial == 0 ? colunas + 1 : colunas - 1)
        cor_inicial = (cor_inicial == 0 ? 1 : 0)
    }

    define_bombas();
}

function verifica_bombas (num) {
    let bomba_ja_existe = posicoes_bombas.find(element => element == num);

    bomba_ja_existe = (bomba_ja_existe == undefined ? false : true)

    return bomba_ja_existe
}

function define_bombas(){

    for(let i=0; i<num_bombas; i++){

        do {
            random_num =  get_random_int(0, (tam_colunas * tam_linhas))
            bomba_ja_existe = verifica_bombas(random_num)
            // console.log(bomba_ja_existe + " , " + random_num)
        }while(bomba_ja_existe)

        posicoes_bombas.push(random_num);

    }
    
    console.log(posicoes_bombas); //para testarmos
}

function get_random_int(min, max) { //retorna um inteiro entre min e max, sem incluir max
    let random = Math.random()
    let num = Math.floor(random * (max - min)) + min
    return num
}


function limpa_tabuleiro() {
    let acha_linha = document.getElementsByClassName("linha")
    let acha_quadrado = document.getElementsByClassName("quadrado")
    
    let size_quadrados = acha_quadrado.length
    let size_linhas = acha_linha.length
    
    for(let i = 0; i < size_quadrados; i++ ){
        acha_quadrado[0].remove()
    }

    for(let i = 0; i < size_linhas; i++)
    {
        acha_linha[0].remove()
    }

    posicoes_bombas = []
}

