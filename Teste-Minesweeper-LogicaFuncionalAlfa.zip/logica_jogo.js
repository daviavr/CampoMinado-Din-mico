function get_quadrado(linha, coluna) {
    posicao = (linha *= tam_colunas) + coluna
    let quadrado = document.getElementsByClassName("quadrado")[posicao]
    return quadrado
}

function mostra_qtde_bombas(linha,coluna){
    let coordenadas = get_coordenadas(linha,coluna)
    let qtde_bombas = qtde_bombas_ao_redor(coordenadas)
    let quadrado = get_quadrado(linha,coluna);
    

    quadrado.innerHTML = qtde_bombas;
    quadrado.classList.add("hover")
}

function mostra_bombas() {

    for (let i = 0; i < num_bombas; i++) {
        let pos = posicoes_bombas[i];
        let quadrado = document.getElementsByClassName("quadrado")[pos];
        quadrado.innerHTML = "B";
    }

}

function verifica_bombas (posicao) {
    let ha_bomba = posicoes_bombas.find(element => element == posicao);

    ha_bomba = (ha_bomba == undefined ? false : true)

    return ha_bomba
}

function get_posicao_absoluta(linha, coluna) {
    return ((linha * tam_colunas) + coluna)
}

function get_coordenadas(linha_central,coluna_central) {
    let linha_inicial = linha_central - 1, coluna_inicial = coluna_central - 1;
    let linha_final = linha_central + 1, coluna_final = coluna_central + 1;
    // console.log("Depois: " + linha_inicial + " , " + coluna_inicial + " , " + linha_final + " , " + coluna_final)


    linha_inicial = (linha_inicial < 0 ? linha_inicial = 0 : linha_inicial);
    coluna_inicial = (coluna_inicial < 0 ? coluna_inicial = 0 : coluna_inicial);

    linha_final = (linha_final >= tam_linhas ? (linha_final = tam_linhas - 1) : linha_final);
    coluna_final = (coluna_final >= tam_colunas ? (coluna_final = tam_colunas - 1) : coluna_final);

    return {
        linha_inicial,
        coluna_inicial,
        linha_final,
        coluna_final,
        linha_central,
        coluna_central
    };
}

function qtde_bombas_ao_redor(coordenadas){
    let ha_bomba, bombas_ao_redor = 0

    let { linha_inicial, coluna_inicial, linha_final, 
        coluna_final, linha_central, coluna_central } = coordenadas;

    for (let i = linha_inicial; i <= linha_final; i++) {
        for (let n = coluna_inicial; n <= coluna_final; n++) {
            posicao_absoluta = get_posicao_absoluta(i, n);
            ha_bomba = verifica_bombas(posicao_absoluta);
            if(ha_bomba){
                if (i != linha_central || n != coluna_central) {
                    bombas_ao_redor++;
                }
            }
        }
    }
    return bombas_ao_redor
}

function abre_posicoes(coordenadas) {
    // console.log(ha_bombas)

    let { linha_inicial, coluna_inicial, linha_final, 
        coluna_final, linha_central, coluna_central } = coordenadas;
    
    let ha_bombas = qtde_bombas_ao_redor(coordenadas)


    let quadrado 

    if(ha_bombas == 0){
        for (let i = linha_inicial; i <= linha_final; i++) {
            for (let n = coluna_inicial; n <= coluna_final; n++) {
                if (i != linha_central || n != coluna_central) {
                    quadrado = get_quadrado(i,n)
                    if(quadrado.innerHTML == ""){
                        let novas_coordenadas = get_coordenadas(i,n)
                        quadrado.innerHTML = 0
                        quadrado.classList.add("hover")
                        console.log(i + "," + n)
                        // await sleep(2000)
                        abre_posicoes(novas_coordenadas)
                    }
                    else
                        continue
                }
            }
        }
    }
    else {
        return mostra_qtde_bombas(linha_central,coluna_central)
    }

}


function pressiona_quadrado(linha, coluna) {
    // let quadrado = get_quadrado(linha, coluna);
    let posicao_absoluta = get_posicao_absoluta(linha, coluna);
    let ha_bomba = verifica_bombas(posicao_absoluta);
    let coordenadas = get_coordenadas(linha,coluna);
    // console.log(coordenadas);
    // console.log("teste")


    if (ha_bomba) {
        mostra_bombas()

        alert("Você perdeu!")

        // new Historico(nome_jogador, `${tam_linhas}, ${tam_colunas}`, num_bombas, modalidade, tempo, "Derrota", new Date);
    }
    else {

        abre_posicoes(coordenadas)

        mostra_qtde_bombas(linha, coluna)

    }


}





// class Historico{

//     constructor(nome_jogador, dimensoes, num_bombas, modalidade, tempo_total, resultado, data_hora){
//         this.nome_jogador= nome_jogador
//         this.dimensoes = dimensoes
//         this.num_bombas = num_bombas
//         this.modalidade = modalidade
//         this.tempo_total = tempo_total
//         this.resultado = resultado
//         this.data_hora = data_hora
//     }
// }
